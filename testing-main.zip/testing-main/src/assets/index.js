import animation from './animation_ll9lnnj9.json'
import animation1 from './animation_ll9nqujt.json'
import animation2 from './animation_ll9nvblx.json'
import animation3 from './animation_llqlh84o.json'
import img1 from './Med-Rec-Process-1.png'
import img2 from './img1.jpeg'
export{
    animation,
    animation1,
    animation2,
    animation3,
    img1,
    img2
};