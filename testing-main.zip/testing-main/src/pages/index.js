import Home from "./Home";
import About from "./About";
import Contact from "./Contact";
import Inputdata from "./Inputdata";
import Login from "./Login";
import Register from "./Register";


export{
    Home,
    About, 
    Contact,
    Inputdata,
    Login,
    Register
}