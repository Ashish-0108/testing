const host = 'http://localhost:5000';
export const  registerRoute = `${host}/register`;
export const  loginRoute = `${host}/login`;
export const inputRoute=`${host}/summarize`;

