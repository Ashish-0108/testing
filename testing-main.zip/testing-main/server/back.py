from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
import bcrypt
from flask_cors import CORS  # Import CORS from flask_cors
import json
import pandas as pd
import io
import csv
app = Flask(__name__)

# Enable CORS for your app
CORS(app)

# Configure your MongoDB URI (change to your MongoDB connection details)
app.config['MONGO_URI'] = 'mongodb+srv://ashishgolla2003:NS011618@cluster0.ophbpqo.mongodb.net/patient'
mongo = PyMongo(app)

# Define a MongoDB collection name
users_collection = mongo.db.users
@app.route('/signup', methods=['POST'])
def signup():
    try:
        data = request.get_json()
        username = data['username']        
        password = data['password']
        confirm_password = data['confirmPassword']  # Add confirm password

        # Check if the username or email already exists
        if users_collection.find_one({'$or': [{'username': username}]}):
            return jsonify({'status': False, 'msg': 'Username already exists'}), 400

        # Check if password and confirm password match
        if password != confirm_password:
            return jsonify({'status': False, 'msg': 'Password and confirm password do not match'}), 400

        # Hash the password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        # Insert the new user data into the database
        user_id = users_collection.insert_one({'username': username,  'password': hashed_password}).inserted_id

        return jsonify({'status': True, 'msg': 'Registered successfully', 'user_id': str(user_id)}), 201

    except Exception as e:
        return jsonify({'status': False, 'msg': str(e)}), 500

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data['username']
        password = data['password']

        # Find the user by username
        user = users_collection.find_one({'username': username})

        if user and bcrypt.checkpw(password.encode('utf-8'), user['password']):
            return jsonify({'status': True, 'msg': 'Login successful'}), 200
        else:
            return jsonify({'status': False, 'msg': 'Invalid username or password'}), 401

    except Exception as e:
        return jsonify({'status': False, 'msg': str(e)}), 500


# Define the route where the frontend will post the CSV data
@app.route('/summarize', methods=['POST'])
def summarize():
    try:
        data = request.get_json()  # Get the CSV data as JSON from the frontend

        if not data:
            return jsonify({'message': 'No data received'}), 400

        # Define the path to save the CSV file
        csv_filename = 'uploaded_data.csv'

        # Write the CSV data to the file
        with open(csv_filename, 'w', newline='') as csvfile:
            csv_writer = csv.DictWriter(csvfile, fieldnames=data[0].keys())
            csv_writer.writeheader()
            csv_writer.writerows(data)

        return jsonify({'message': 'Data received and saved successfully'}), 200

    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
